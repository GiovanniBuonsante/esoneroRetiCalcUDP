/*
 ============================================================================
 Name        : protocol.h
 Author      : Buonsante Giovanni
 Version     : 1.01
 Copyright   : Your copyright notice
 Description : Calculator UDP in C, Ansi-style
 ============================================================================
 */
#ifndef PROTOCOL_H
#define PROTOCOL_H

#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define closesocket close
#endif

#define NO_ERROR 0
#define BUFFMAX 255
#define PORT 56700

///declaration of the operation and function
int add(int num1, int num2) {
    return num1 + num2;
}
int subtract(int num1, int num2) {
    return num1 - num2;
}
double multiply(int num1, int num2) {
    return num1 * num2;
}
double divide(int num1, int num2) {
    if (num2 != 0) {
        return (double) num1 / num2;
    } else {
        return 0;
    }
}
void errorhandler(const char *error_message)
{
    printf("%s\n", error_message);
}
void clearwinsock()
{
#if defined WIN32
    WSACleanup();
#endif
}

#endif
