/*
 ============================================================================
 Name        : server.c
 Author      : Buonsante Giovanni
 Version     : 1.01
 Copyright   : Your copyright notice
 Description : Calculator UDP in C, Ansi-style
 ============================================================================
 */
/// include the protocol.h
#include "protocol.h"

int main(void) {
    #if defined WIN32
        // Initialize Winsock
        WSADATA wsa_data;
        int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
        if (result != NO_ERROR)
        {
            printf("Error at WSAStartup()\n");
            return 0;
        }
    #endif

    int my_socket;
    char operation;
    int num1,num2;

    /// create a UDP socket
    if ((my_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
    {
        errorhandler("Error creating socket");
        clearwinsock();
        return EXIT_FAILURE;
    }

    /// set the server address
    struct sockaddr_in server_address;
    struct sockaddr_in client_address;
    unsigned int client_address_length = sizeof(client_address);
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(PORT);
    //server_address.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);

    /// check bind
    if ((bind(my_socket, (struct sockaddr *)&server_address,
              sizeof(server_address))) < 0)
    {
        errorhandler("bind() failed");
        closesocket(my_socket);
        clearwinsock();
        return EXIT_FAILURE;
    }

    /// declare buffer
    char buffer[BUFFMAX];

    int rcv_msg_size;
    ///
    while (1) {
        puts("\nServer listening...");

        /// receive data from the client
        /// clean buffer
        memset(buffer, 0, BUFFMAX);
        if ((rcv_msg_size = recvfrom(my_socket, buffer, BUFFMAX, 0, (struct sockaddr *)&client_address, &client_address_length)) < 0) {
            errorhandler("recvfrom() data failed");
            closesocket(my_socket);
            clearwinsock();
            return EXIT_FAILURE;
        }

        /// if in the buffer there is char '=' break the connection with that client.
        ///  Exit the loop and close the connection with the current client
        if (strcmp(buffer, "=") == 0) {
            printf("Client requested to close the connection. Closing...\n");
        } else {
            /// split the buffer in three variable
            sscanf(buffer, "%c %d %d", &operation, &num1, &num2);
            struct hostent *client_host = gethostbyaddr((char *) &client_address.sin_addr.s_addr,
                                                        sizeof(client_address.sin_addr.s_addr), AF_INET);
            printf("Richiesta operazione '%c %d %d' dal client %s, ip %s", operation, num1, num2, client_host->h_name,
                   inet_ntoa(client_address.sin_addr));

            double result = 0;

            ///Calculation.
            char err[20]; ///Error string.
            if (operation == '+') {
                result = add(num1,num2);
            } else if (operation == '-') {
                result = subtract(num1,num2);
            } else if (operation == '*') {
                result = multiply(num1,num2);
            } else if (operation == '/') {
                if (num2 != 0) {
                    result = divide(num1,num2);
                } else {
                    strcpy(err, "Math Error!");
                }
            } else {
                strcpy(err, "Unknown operation!");
            }

            char response_buffer[BUFFMAX];
            /// clean buffer
            memset(response_buffer, 0, BUFFMAX);
            /// check if there is an error
            if (strlen(err) > 0) {
                strcpy(response_buffer, err);
            } else {
                char charNum1[BUFFMAX];
                char charNum2[BUFFMAX];
                /// transform from variable int to variable char
                sprintf(charNum1, "%d", num1);
                sprintf(charNum2, "%d", num2);
                /// append const char to create the string
                strcat(response_buffer, charNum1);
                strcat(response_buffer," ");
                strcat(response_buffer, &operation);
                strcat(response_buffer," ");
                strcat(response_buffer, charNum2);
                strcat(response_buffer," ");
                strcat(response_buffer,"=");
                strcat(response_buffer," ");
                ///We used it here to convert double to string.
                char resultChar[BUFFMAX];
                sprintf(resultChar, "%.2f", result);
                /// append the resultChar at the response buffer
                strcat(response_buffer,resultChar);
            }
            printf("\nSending '%s' back to client\n", response_buffer);

            /// sending buffer to the client
            if (sendto(my_socket, response_buffer, strlen(response_buffer), 0,
                       (struct sockaddr *) &client_address, sizeof(client_address)) != strlen(response_buffer)) {
                errorhandler("sendto() sent a different number of bytes than expected");
                closesocket(my_socket);
                clearwinsock();
                return EXIT_FAILURE;
            }
            memset(buffer, 0, BUFFMAX);
        }
    }
}


