/*
 ============================================================================
 Name        : client.c
 Author      : Buonsante Giovanni
 Version     : 1.01
 Copyright   : Your copyright notice
 Description : Calculator UDP in C, Ansi-style
 ============================================================================
 */
/// include the protocol.h
#include "protocol.h"


int main(void) {
    #if defined WIN32
        // Initialize Winsock
        WSADATA wsa_data;
        int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
        if (result != NO_ERROR)
        {
            printf("Error at WSAStartup()\n");
            return 0;
        }
    #endif

    char buffer[BUFFMAX];
    char nameServer[25];
    memset(buffer, 0, BUFFMAX);
    char *delim = ":";
    char *name;
    int port;
    puts("Enter the server name and port (in the format servername:port):");
    fgets(buffer, BUFFMAX, stdin);

    /// split buffer into name:port
    /// if buffer is null, upload on buffer the string "localhost:56700"
    if(buffer[0] == '\n') {
        strcpy(buffer,"localhost:56700");
        name = strtok(buffer, delim);
        stpcpy(nameServer, name);
        port = atoi(strtok(NULL, delim));
    } else {
        name = strtok(buffer, delim);
        stpcpy(nameServer, name);
        port = atoi(strtok(NULL, delim));
    }
    struct hostent *host = gethostbyname(name);
    if (host == NULL)
    {
        errorhandler("Error getting host");
        clearwinsock();
        return EXIT_FAILURE;
    }
    printf("Server name: %s (IP: %s, port: %d)\n", nameServer, inet_ntoa(*(struct in_addr *)host->h_addr), port);

    int my_socket;
    struct sockaddr_in server_address;
    unsigned int server_address_size = sizeof(server_address);

    int rcv_msg_size;

    /// create a UDP socket
    if ((my_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
    {
        errorhandler("Error creating socket");
        clearwinsock();
        return EXIT_FAILURE;
    }

    /// set the server address
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(port);
    server_address.sin_addr = *((struct in_addr *)host->h_addr);

    while (1) {

        puts("\nEnter the string to send to the server: + - * / es: + 45 67");
        printf("▶︎ ");
        memset(buffer, 0, BUFFMAX);
        fgets(buffer, BUFFMAX, stdin);
        size_t len = strlen(buffer);
        if (len > 0 && buffer[len - 1] == '\n') {
            buffer[len - 1] = '\0';
        }
        ///if the user input '=' break the loop.
        if (strcmp(buffer, "=") == 0)
        {
            /// send the char "=" to the server to inform it of the closure
            sendto(my_socket, buffer, strlen(buffer), 0,
                   (struct sockaddr *)&server_address, sizeof(server_address));
            break;
        }
        /// send data to the server
        if (sendto(my_socket, buffer, strlen(buffer), 0,
                   (struct sockaddr *) &server_address, sizeof(server_address)) != strlen(buffer)) {
            errorhandler("Error sending data");
            closesocket(my_socket);
            clearwinsock();
            return EXIT_FAILURE;
        }

        /// receive a message from the server
        /// clean buffer
        memset(buffer, 0, BUFFMAX);
        if ((rcv_msg_size = recvfrom(my_socket, buffer, BUFFMAX, 0,
                                     (struct sockaddr *) &server_address, &server_address_size)) < 0) {
            errorhandler("Error receiving data");
            closesocket(my_socket);
            clearwinsock();
            return EXIT_FAILURE;
        }

        /// print the received message from the server
        /// client read the response message received from the server
        printf("Ricevuto risultato dal server %s, ip %s: %s\n", nameServer,
               inet_ntoa(*(struct in_addr *) host->h_addr), buffer);
    }
    closesocket(my_socket);
    clearwinsock();
    return EXIT_SUCCESS;
}


